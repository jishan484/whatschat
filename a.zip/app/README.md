<!-- to do -->

1. add profile system [done]
2. add profile image link [done]
3. notification and friends update system[half]
4. chat with emoji [nope]
5. service worker[nope]
6. ofline page handle [help]
7. save data to local storage [done]
8. add cancle request button
   <!-- end date 28/07/2020 -->
